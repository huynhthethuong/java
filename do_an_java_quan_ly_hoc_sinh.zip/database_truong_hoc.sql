-- MySQL dump 10.13  Distrib 8.0.18, for macos10.14 (x86_64)
--
-- Host: localhost    Database: truong_hoc
-- ------------------------------------------------------
-- Server version	8.0.18

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `diem`
--

DROP TABLE IF EXISTS `diem`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `diem` (
  `mahs` char(5) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `mamh` char(5) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `mahk` char(1) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `manh` char(4) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `maLoaiDiem` char(2) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `diemSo` float DEFAULT NULL,
  PRIMARY KEY (`mahs`,`mamh`,`mahk`,`manh`,`maLoaiDiem`),
  KEY `fk_diem_hocky_idx` (`mahk`),
  KEY `fk_diem_namhoc_idx` (`manh`),
  KEY `fk_diem_monhoc_idx` (`mamh`),
  KEY `fk_diem_loaidiem_idx` (`maLoaiDiem`),
  CONSTRAINT `fk_diem_hocky` FOREIGN KEY (`mahk`) REFERENCES `hoc_ki` (`mahk`),
  CONSTRAINT `fk_diem_hocsinh` FOREIGN KEY (`mahs`) REFERENCES `hoc_sinh` (`mahs`),
  CONSTRAINT `fk_diem_loaidiem` FOREIGN KEY (`maLoaiDiem`) REFERENCES `loai_diem` (`maLoaiDiem`),
  CONSTRAINT `fk_diem_monhoc` FOREIGN KEY (`mamh`) REFERENCES `mon_hoc` (`mamh`),
  CONSTRAINT `fk_diem_namhoc` FOREIGN KEY (`manh`) REFERENCES `nam_hoc` (`manh`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `diem`
--

LOCK TABLES `diem` WRITE;
/*!40000 ALTER TABLE `diem` DISABLE KEYS */;
INSERT INTO `diem` VALUES ('12024','MH001','1','2019','15',0),('12024','MH001','1','2019','1T',0),('12024','MH001','1','2019','HK',0),('12024','MH001','2','2019','15',0),('12024','MH001','2','2019','1T',0),('12024','MH001','2','2019','HK',0),('12024','MH002','1','2019','15',0),('12024','MH002','1','2019','1T',0),('12024','MH002','1','2019','HK',0),('12024','MH002','2','2019','15',0),('12024','MH002','2','2019','1T',0),('12024','MH002','2','2019','HK',0),('12024','MH003','1','2019','15',0),('12024','MH003','1','2019','1T',0),('12024','MH003','1','2019','HK',0),('12024','MH003','2','2019','15',0),('12024','MH003','2','2019','1T',0),('12024','MH003','2','2019','HK',0),('12024','MH004','1','2019','15',0),('12024','MH004','1','2019','1T',0),('12024','MH004','1','2019','HK',0),('12024','MH004','2','2019','15',0),('12024','MH004','2','2019','1T',0),('12024','MH004','2','2019','HK',0),('12024','MH005','1','2019','15',0),('12024','MH005','1','2019','1T',0),('12024','MH005','1','2019','HK',0),('12024','MH005','2','2019','15',0),('12024','MH005','2','2019','1T',0),('12024','MH005','2','2019','HK',0),('12024','MH006','1','2019','15',0),('12024','MH006','1','2019','1T',0),('12024','MH006','1','2019','HK',0),('12024','MH006','2','2019','15',0),('12024','MH006','2','2019','1T',0),('12024','MH006','2','2019','HK',0),('12024','MH007','1','2019','15',0),('12024','MH007','1','2019','1T',0),('12024','MH007','1','2019','HK',0),('12024','MH007','2','2019','15',0),('12024','MH007','2','2019','1T',0),('12024','MH007','2','2019','HK',0);
/*!40000 ALTER TABLE `diem` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `diem_hocki`
--

DROP TABLE IF EXISTS `diem_hocki`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `diem_hocki` (
  `mahs` char(5) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `mamh` char(5) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `mahk` char(1) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `manh` char(4) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `tbmonhk` float DEFAULT NULL,
  PRIMARY KEY (`mahs`,`mamh`,`mahk`,`manh`),
  KEY `fk_diemhocky_diem_hocsinh_idx` (`mahs`),
  KEY `fk_diemhocky_diem_hocky_idx` (`mahk`),
  KEY `fk_diemhocky_diem_monhoc_idx` (`mamh`),
  KEY `fk_diemhocky_diem_namhoc_idx` (`manh`),
  CONSTRAINT `fk_diemhocky_diem_hocky` FOREIGN KEY (`mahk`) REFERENCES `hoc_ki` (`mahk`),
  CONSTRAINT `fk_diemhocky_diem_hocsinh` FOREIGN KEY (`mahs`) REFERENCES `hoc_sinh` (`mahs`),
  CONSTRAINT `fk_diemhocky_diem_monhoc` FOREIGN KEY (`mamh`) REFERENCES `mon_hoc` (`mamh`),
  CONSTRAINT `fk_diemhocky_diem_namhoc` FOREIGN KEY (`manh`) REFERENCES `nam_hoc` (`manh`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `diem_hocki`
--

LOCK TABLES `diem_hocki` WRITE;
/*!40000 ALTER TABLE `diem_hocki` DISABLE KEYS */;
INSERT INTO `diem_hocki` VALUES ('12024','MH001','1','2019',0),('12024','MH001','2','2019',0),('12024','MH002','1','2019',0),('12024','MH002','2','2019',0),('12024','MH003','1','2019',0),('12024','MH003','2','2019',0),('12024','MH004','1','2019',0),('12024','MH004','2','2019',0),('12024','MH005','1','2019',0),('12024','MH005','2','2019',0),('12024','MH006','1','2019',0),('12024','MH006','2','2019',0),('12024','MH007','1','2019',0),('12024','MH007','2','2019',0);
/*!40000 ALTER TABLE `diem_hocki` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `giao_vien`
--

DROP TABLE IF EXISTS `giao_vien`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `giao_vien` (
  `magv` char(5) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `ho` varchar(45) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `ten` varchar(45) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `monPhuTrach` char(5) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`magv`),
  KEY `fk_giaovien_monhoc_idx` (`monPhuTrach`),
  CONSTRAINT `fk_giaovien_monhoc` FOREIGN KEY (`monPhuTrach`) REFERENCES `mon_hoc` (`mamh`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `giao_vien`
--

LOCK TABLES `giao_vien` WRITE;
/*!40000 ALTER TABLE `giao_vien` DISABLE KEYS */;
INSERT INTO `giao_vien` VALUES ('00001','Nguyen Tang','Vu','MH001'),('00002','Nguyen Thi','Nguyet','MH002'),('00003','Nguyen Thi Thu','Linh','MH003'),('00004','Nguyen Phuong','Bac','MH004'),('00005','Dinh Thu ','Huong','MH005'),('00006','Huynh Kim','Lien','MH006'),('00007','Nguyen Phuong','Nam','MH001'),('00008','Tran Ngoc','Phung','MH003'),('00009','Dang Thuy','Tram','MH004');
/*!40000 ALTER TABLE `giao_vien` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hoc_ba_cuoi_nam`
--

DROP TABLE IF EXISTS `hoc_ba_cuoi_nam`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hoc_ba_cuoi_nam` (
  `mahs` char(5) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `manh` char(4) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `hocLuc` varchar(45) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `hanhKiem` varchar(45) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `xepLoai` varchar(45) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `dtbCn` float DEFAULT NULL,
  PRIMARY KEY (`mahs`,`manh`),
  KEY `fk_hocba_namhoc_idx` (`manh`),
  CONSTRAINT `fk_hocba_hocsinh` FOREIGN KEY (`mahs`) REFERENCES `hoc_sinh` (`mahs`),
  CONSTRAINT `fk_hocba_namhoc` FOREIGN KEY (`manh`) REFERENCES `nam_hoc` (`manh`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hoc_ba_cuoi_nam`
--

LOCK TABLES `hoc_ba_cuoi_nam` WRITE;
/*!40000 ALTER TABLE `hoc_ba_cuoi_nam` DISABLE KEYS */;
INSERT INTO `hoc_ba_cuoi_nam` VALUES ('12024','2019','Yeu','chưa có đánh giá','chưa có đánh giá',0);
/*!40000 ALTER TABLE `hoc_ba_cuoi_nam` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hoc_ki`
--

DROP TABLE IF EXISTS `hoc_ki`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hoc_ki` (
  `mahk` char(1) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `tenhk` varchar(45) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`mahk`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hoc_ki`
--

LOCK TABLES `hoc_ki` WRITE;
/*!40000 ALTER TABLE `hoc_ki` DISABLE KEYS */;
INSERT INTO `hoc_ki` VALUES ('1','HK1'),('2','HK2');
/*!40000 ALTER TABLE `hoc_ki` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hoc_sinh`
--

DROP TABLE IF EXISTS `hoc_sinh`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hoc_sinh` (
  `mahs` char(5) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `ho` varchar(45) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `ten` varchar(45) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `phai` varchar(45) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `ngaysinh` varchar(45) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `diachi` varchar(90) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `quequan` varchar(90) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `hinhanh` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`mahs`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hoc_sinh`
--

LOCK TABLES `hoc_sinh` WRITE;
/*!40000 ALTER TABLE `hoc_sinh` DISABLE KEYS */;
INSERT INTO `hoc_sinh` VALUES ('11001','Nguyen Ngoc','Thai','Nam','2003-11-09','Quan 2, TPHCM','Vung Tau','/Users/mr932/Downloads/72673455_3284643418235748_1372620424805875712_o.jpg'),('11002','Tran Thien','Phuc','Nam','2003-08-26','Quan 7, TPHCM','TPHCM','/Users/mr932/Downloads/70234507_2549856615141853_2868056616261910528_n.jpg'),('11003','Truong Ngoc','Huy','Nam','2003-05-24','Quan Tan Phu, TPHCM','Da Lat','null'),('11004','Pham Xuan','Ha','Nam','2003-03-27','Quan 5, TPHCM','TPHCM','/Users/mr932/Downloads/74379933_143878397007752_4581616179293978624_o.jpg'),('11005','Truong Tan','Phat','Nam','2003-12-02','Quan Binh Chanh, TPHCM','An Giang','null'),('11006','Le Minh','Quan','Nam','2003-07-02','Quan Go Vap, TPHCM','Hai Phong',NULL),('11007','Phan Huy','Trung ','Nam','2003-08-08','Quan Binh Tan, TPHCM','Thai Binh',NULL),('11008','Nguyen Thi','Bong','Nu','2003-03-09','Quan 9, TPHCM','Binh Phuoc',NULL),('11009','Tran Minh','Tam','Nam ','2003-02-23','Huyen Nha Be, TPHCM','TPHCM',NULL),('11010','Truong Minh','Anh','Nu','2003-12-08 ','Quan Binh Thanh, TPHCM','TPHCM',NULL),('11011','Tu Gia','Long','Nam','2003-04-03','Quan 8, TPHCM','TPHCM',NULL),('11012','Ta Hieu ','Thi','Nu','2003-07-05','Quan 9, TPHCM','TPHCM',NULL),('11013','Huynh Gia','Lam ','Nam','2003-09-23','Quan 4, TPHCM','Long An',NULL),('11014','Truong Huynh','Nhu ','Nu','2003-12-01','Quan Tan Binh, TPHCM','Ha Noi',NULL),('11015','Nguyen Tuong','Vi','Nu','2003-11-24','Quan Tan Binh, TPHCM','TPHCM',NULL),('11016','Pham Quynh ','Thi','Nu','2003-09-15','Quan 1, TPHCM','TPHCM',NULL),('11017','Vo Tien ','Huy ','Nam','2003-10-10','Quan  Tan Phu, TPHCM','Binh Thuan',NULL),('11018','Vu Hoai','Son','Nam ','2003-08-09 ','Quan 7, TPHCM','TPHCM',NULL),('11019','Ngo Kim ','Sang','Nam ','2003-09-17','Quan 3,  TPHCM','Gia Lai',NULL),('11020','Nguyen Thi ','Thao ','Nu','2003-12-15','Quan Tan Phu, TPHCM','Hung Yen',NULL),('12001','Nguyen Dinh','Man ','Nam','2002-08-13','Quan Binh Thanh, TPHCM','Phu Yen',NULL),('12002','Nguyen Thi Thu','Linh','Nu','2002-09-28','Quan Tan Binh, TPHCM','Phu Yen',NULL),('12003','Cao Anh','Tuan','Nam ','2002-12-08','Quan 2, TPHCM','TPHCM',NULL),('12004','Nguyen Duc','Minh','Nam','2002-08-23','Quan Binh Chanh, TPHCM','TPHCM',NULL),('12005','Tran Ngoc ','Thu','Nu','2002-02-27','Huyen Nha Be, TPHCM','TPHCM',NULL),('12006','Dinh Hoang ','Nhut','Nam','2002-07-17','Quan 4, TPHCM','TPHCM',NULL),('12007','Tranh Minh ','Nhat','Nam ','2002-02-25','Quan 7, TPHCM','Gia Lai',NULL),('12008','Nguyen Phuc','Mai','Nu','2002-12-29','Quan Go Vap , TPHCM','TPHCM',NULL),('12009','Tran Duy','Du','Nam','2002-12-19','Quan Tan Binh, TPHCM','TPHCM',NULL),('12010','Nguyen Thu','Yen','Nu','2002-05-05','Quan Phu Nhuan, TPHCM','TPHCM',NULL),('12011','Tran Ngoc','An','Nu','2002-05-02','Quan Go Vap, TPHCM','Vung Tau',NULL),('12012','Nguyen Thi ','Bong','Nu','2002-08-10','Quan Tan Phu, TPHCM','TPHCM',NULL),('12013','Nguyen Tan','Sang','Nam','2002 12-07','Quan 12, TPHCM','TPHCM',NULL),('12014','Phan Tuan ','Anh','Nam','2002-12-09','Quan 3, TPHCM','TPHCM',NULL),('12015','Ngo Anh ','Tuan','Nam','2002-09-13','Quan 3, TPHCM','TPHCM',NULL),('12016','Nguyen Minh','Quan','Nam','2002-04-07','Quan 2, TPHCM','TPHCM',NULL),('12017','Nguyen Van ','Teo ','Nam','2002-09-14','Huyen Nha Be, TPHCM','TPHCM',NULL),('12018','Nguyen Thi','Hoa','Nu','2002-11-05','Quan 4, TPHCM','TPHCM',NULL),('12019','Le Van','Ti','Nam','2002-06-29','Quan 8, TPHCM','Vung Tau',NULL),('12020','Tran Thi','Bich','Nu','2002-02-17','Quan Thu Duc, TPHCM ','Long An',NULL),('12021','Tran Thi','Bich','Nam','2002-02-17','Quan Thu Duc, TPHCM','Long An','/Users/mr932/Downloads/74403993_978956012451848_8066261337111527424_n.jpg'),('12024','Tran Thi','Bich','Nam','2002-02-17','Quan Thu Duc, TPHCM','Long An','null');
/*!40000 ALTER TABLE `hoc_sinh` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hocsinh_lop`
--

DROP TABLE IF EXISTS `hocsinh_lop`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hocsinh_lop` (
  `mahs` char(5) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `malop` char(5) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `mahk` char(1) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `manh` char(4) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`mahs`,`malop`,`mahk`,`manh`),
  KEY `fk_hocsinhlop_malop_idx` (`malop`),
  KEY `fk_hocsinhlop_hocky_idx` (`mahk`),
  KEY `fk_hocsinhlop_namhoc_idx` (`manh`),
  CONSTRAINT `fk_hocsinhlop_hocky` FOREIGN KEY (`mahk`) REFERENCES `hoc_ki` (`mahk`),
  CONSTRAINT `fk_hocsinhlop_hocsinh` FOREIGN KEY (`mahs`) REFERENCES `hoc_sinh` (`mahs`),
  CONSTRAINT `fk_hocsinhlop_malop` FOREIGN KEY (`malop`) REFERENCES `lop` (`maLop`),
  CONSTRAINT `fk_hocsinhlop_namhoc` FOREIGN KEY (`manh`) REFERENCES `nam_hoc` (`manh`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hocsinh_lop`
--

LOCK TABLES `hocsinh_lop` WRITE;
/*!40000 ALTER TABLE `hocsinh_lop` DISABLE KEYS */;
INSERT INTO `hocsinh_lop` VALUES ('12024','LO101','1','2019'),('12024','LO101','2','2019');
/*!40000 ALTER TABLE `hocsinh_lop` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ketqua_hoctap_hocki`
--

DROP TABLE IF EXISTS `ketqua_hoctap_hocki`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ketqua_hoctap_hocki` (
  `mahs` char(5) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `mahk` char(1) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `manh` char(4) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `hanhKiem` varchar(45) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `tbchk` float DEFAULT NULL,
  PRIMARY KEY (`mahs`,`mahk`,`manh`),
  KEY `fk_ketquahocky_diemhocky_hocsinh_idx` (`mahs`),
  KEY `fk_ketquahocky_diemhocky_hocky_idx` (`mahk`),
  KEY `fk_ketquahocky_diemhocky_namhoc_idx` (`manh`),
  CONSTRAINT `fk_ketquahocky_diemhocky_hocky` FOREIGN KEY (`mahk`) REFERENCES `hoc_ki` (`mahk`),
  CONSTRAINT `fk_ketquahocky_diemhocky_hocsinh` FOREIGN KEY (`mahs`) REFERENCES `hoc_sinh` (`mahs`),
  CONSTRAINT `fk_ketquahocky_diemhocky_namhoc` FOREIGN KEY (`manh`) REFERENCES `nam_hoc` (`manh`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ketqua_hoctap_hocki`
--

LOCK TABLES `ketqua_hoctap_hocki` WRITE;
/*!40000 ALTER TABLE `ketqua_hoctap_hocki` DISABLE KEYS */;
INSERT INTO `ketqua_hoctap_hocki` VALUES ('12024','1','2019','',0),('12024','2','2019','',0);
/*!40000 ALTER TABLE `ketqua_hoctap_hocki` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `loai_diem`
--

DROP TABLE IF EXISTS `loai_diem`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `loai_diem` (
  `maLoaiDiem` char(2) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `tenLoaiDiem` varchar(45) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `heSo` float DEFAULT NULL,
  PRIMARY KEY (`maLoaiDiem`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `loai_diem`
--

LOCK TABLES `loai_diem` WRITE;
/*!40000 ALTER TABLE `loai_diem` DISABLE KEYS */;
INSERT INTO `loai_diem` VALUES ('15','Diem 15 phut',1),('1T','Diem 1 tiet',2),('HK','Diem thi Hoc Ki',3);
/*!40000 ALTER TABLE `loai_diem` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lop`
--

DROP TABLE IF EXISTS `lop`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lop` (
  `maLop` char(5) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `tenLop` varchar(45) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `manh` char(5) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `maGVCN` char(5) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `siSo` int(11) DEFAULT NULL,
  `maphong` char(4) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`maLop`),
  KEY `fk_lop_phong_idx` (`maphong`),
  CONSTRAINT `fk_lop_phong` FOREIGN KEY (`maphong`) REFERENCES `phong` (`maphong`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lop`
--

LOCK TABLES `lop` WRITE;
/*!40000 ALTER TABLE `lop` DISABLE KEYS */;
INSERT INTO `lop` VALUES ('LO101','10A1','2019','00001',2,'A101'),('LO102','10A2','2019','00002',0,'A102'),('LO111','11A1','2019','00003',0,'B111'),('LO112','11A2','2019','00004',0,'B112'),('LO121','12A1','2019','00005',0,'C121'),('LO122','12A2','2019','00006',0,'C122');
/*!40000 ALTER TABLE `lop` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mon_hoc`
--

DROP TABLE IF EXISTS `mon_hoc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mon_hoc` (
  `mamh` char(5) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `tenmh` varchar(45) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `heSo` float DEFAULT NULL,
  PRIMARY KEY (`mamh`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mon_hoc`
--

LOCK TABLES `mon_hoc` WRITE;
/*!40000 ALTER TABLE `mon_hoc` DISABLE KEYS */;
INSERT INTO `mon_hoc` VALUES ('MH001','Toan Hoc',2),('MH002','Vat Ly',1),('MH003','Hoa Hoc',1),('MH004','Ngu Van',2),('MH005','Anh Van',1),('MH006','Giao Duc Cong Dan',1),('MH007','Hoa Hoc',1);
/*!40000 ALTER TABLE `mon_hoc` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nam_hoc`
--

DROP TABLE IF EXISTS `nam_hoc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `nam_hoc` (
  `manh` char(4) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `tennh` varchar(45) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`manh`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nam_hoc`
--

LOCK TABLES `nam_hoc` WRITE;
/*!40000 ALTER TABLE `nam_hoc` DISABLE KEYS */;
INSERT INTO `nam_hoc` VALUES ('2017','2017 - 2018'),('2018','2018 -2019'),('2019','2019 -2020');
/*!40000 ALTER TABLE `nam_hoc` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phan_cong_chu_nhiem`
--

DROP TABLE IF EXISTS `phan_cong_chu_nhiem`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `phan_cong_chu_nhiem` (
  `manh` char(4) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `malop` char(5) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `magv` char(5) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`manh`,`malop`),
  KEY `fk_phancongchunhiem_giaovien_idx` (`magv`),
  KEY `fk_phancongchunhiem_lop_idx` (`malop`),
  CONSTRAINT `fk_phancongchunhiem_giaovien` FOREIGN KEY (`magv`) REFERENCES `giao_vien` (`magv`),
  CONSTRAINT `fk_phancongchunhiem_lop` FOREIGN KEY (`malop`) REFERENCES `lop` (`maLop`),
  CONSTRAINT `fk_phancongchunhiem_namhoc` FOREIGN KEY (`manh`) REFERENCES `nam_hoc` (`manh`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phan_cong_chu_nhiem`
--

LOCK TABLES `phan_cong_chu_nhiem` WRITE;
/*!40000 ALTER TABLE `phan_cong_chu_nhiem` DISABLE KEYS */;
INSERT INTO `phan_cong_chu_nhiem` VALUES ('2019','LO101','00001'),('2019','LO102','00002'),('2019','LO111','00003'),('2019','LO112','00004'),('2019','LO121','00005'),('2019','LO122','00006');
/*!40000 ALTER TABLE `phan_cong_chu_nhiem` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phan_cong_giang_day`
--

DROP TABLE IF EXISTS `phan_cong_giang_day`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `phan_cong_giang_day` (
  `manh` char(4) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `malop` char(5) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `mamh` char(5) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `mahk` char(1) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `magv` char(5) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`manh`,`malop`,`mamh`,`mahk`),
  KEY `fk_phancong_namhoc_idx` (`manh`),
  KEY `fk_phanconggiangday_giaovien_idx` (`magv`),
  KEY `fk_phanconggiangday_monhoc_idx` (`mamh`),
  KEY `fk_phanconggiangday_lop_idx` (`malop`),
  KEY `fk_phanconggiangday_hocky_idx` (`mahk`),
  CONSTRAINT `fk_phanconggiangday_giaovien` FOREIGN KEY (`magv`) REFERENCES `giao_vien` (`magv`),
  CONSTRAINT `fk_phanconggiangday_hocky` FOREIGN KEY (`mahk`) REFERENCES `hoc_ki` (`mahk`),
  CONSTRAINT `fk_phanconggiangday_lop` FOREIGN KEY (`malop`) REFERENCES `lop` (`maLop`),
  CONSTRAINT `fk_phanconggiangday_monhoc` FOREIGN KEY (`mamh`) REFERENCES `mon_hoc` (`mamh`),
  CONSTRAINT `fk_phanconggiangday_namhoc` FOREIGN KEY (`manh`) REFERENCES `nam_hoc` (`manh`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phan_cong_giang_day`
--

LOCK TABLES `phan_cong_giang_day` WRITE;
/*!40000 ALTER TABLE `phan_cong_giang_day` DISABLE KEYS */;
INSERT INTO `phan_cong_giang_day` VALUES ('2019','LO112','MH001','2','00001'),('2019','LO112','MH002','1','00002'),('2019','LO112','MH005','1','00005');
/*!40000 ALTER TABLE `phan_cong_giang_day` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phong`
--

DROP TABLE IF EXISTS `phong`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `phong` (
  `maphong` char(4) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `tenPhong` varchar(45) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`maphong`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phong`
--

LOCK TABLES `phong` WRITE;
/*!40000 ALTER TABLE `phong` DISABLE KEYS */;
INSERT INTO `phong` VALUES ('A101','PA101'),('A102','PA102'),('B111','PB111'),('B112','PB112'),('C121','PC121'),('C122','PC122');
/*!40000 ALTER TABLE `phong` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `thoi_khoa_bieu`
--

DROP TABLE IF EXISTS `thoi_khoa_bieu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `thoi_khoa_bieu` (
  `mahk` char(1) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `manh` char(4) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `tietBatDau` int(11) NOT NULL,
  `tietKetThuc` int(11) NOT NULL,
  `malop` char(5) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `thu` varchar(45) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `mamh` char(5) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `magv` char(5) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`mahk`,`manh`,`tietBatDau`,`tietKetThuc`,`malop`,`thu`),
  KEY `fk_thoikhoabieu_namhoc_idx` (`manh`),
  KEY `fk_thoikhoabieu_monhoc_idx` (`mamh`),
  KEY `fk_thoikhoabieu_giaovien_idx` (`magv`),
  KEY `fk_thoikhoabieu_lop_idx` (`malop`),
  CONSTRAINT `fk_thoikhoabieu_giaovien` FOREIGN KEY (`magv`) REFERENCES `giao_vien` (`magv`),
  CONSTRAINT `fk_thoikhoabieu_hocky` FOREIGN KEY (`mahk`) REFERENCES `hoc_ki` (`mahk`),
  CONSTRAINT `fk_thoikhoabieu_lop` FOREIGN KEY (`malop`) REFERENCES `lop` (`maLop`),
  CONSTRAINT `fk_thoikhoabieu_monhoc` FOREIGN KEY (`mamh`) REFERENCES `mon_hoc` (`mamh`),
  CONSTRAINT `fk_thoikhoabieu_namhoc` FOREIGN KEY (`manh`) REFERENCES `nam_hoc` (`manh`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `thoi_khoa_bieu`
--

LOCK TABLES `thoi_khoa_bieu` WRITE;
/*!40000 ALTER TABLE `thoi_khoa_bieu` DISABLE KEYS */;
INSERT INTO `thoi_khoa_bieu` VALUES ('1','2019',1,2,'LO112','Ba','MH005','00005'),('1','2019',1,2,'LO112','Hai','MH005','00005'),('1','2019',1,2,'LO112','Tư','MH005','00005');
/*!40000 ALTER TABLE `thoi_khoa_bieu` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-12-13 10:44:44
